import React, { createContext, useContext, useEffect, useState } from 'react';
import api from '../../services/api';

interface SiteConfig {
    'site.name': string;
    'site.description': string;
    'contact.email': string;
    'contact.phone': string;
    'contact.address': string;
    'social.facebook': string;
    'social.twitter': string;
    'social.instagram': string;
    [key: string]: string;
}

interface ConfigContextType {
    config: SiteConfig;
    isLoading: boolean;
    isError: boolean;
}

// Empty config - no hardcoded defaults
const emptyConfig: SiteConfig = {
    'site.name': '',
    'site.description': '',
    'contact.email': '',
    'contact.phone': '',
    'contact.address': '',
    'social.facebook': '',
    'social.twitter': '',
    'social.instagram': '',
};

const ConfigContext = createContext<ConfigContextType>({
    config: emptyConfig,
    isLoading: true,
    isError: false,
});

export const ConfigProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [config, setConfig] = useState<SiteConfig>(emptyConfig);
    const [isLoading, setIsLoading] = useState(true);
    const [isError, setIsError] = useState(false);

    useEffect(() => {
        const fetchConfig = async () => {
            try {
                const response = await api.get('/system/config');
                if (response.data.success) {
                    setConfig(response.data.data);
                    document.title = response.data.data['site.name'] || 'Store';
                }
            } catch (error) {
                console.error('Failed to load system config', error);
                setIsError(true);
            } finally {
                setIsLoading(false);
            }
        };

        fetchConfig();
    }, []);

    return (
        <ConfigContext.Provider value={{ config, isLoading, isError }}>
            {children}
        </ConfigContext.Provider>
    );
};

export const useConfig = () => useContext(ConfigContext);
