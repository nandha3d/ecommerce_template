<?php

return [
    'name' => env('APP_NAME', 'SupplePro'),
    'version' => '1.0.0',
    'vendor' => 'Antigravity Systems',
    'support_email' => 'support@antigravity.com',
    'license_check_url' => env('LICENSE_CHECK_URL', 'https://api.antigravity.com/verify'),
];
