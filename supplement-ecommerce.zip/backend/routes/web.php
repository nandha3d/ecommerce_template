<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MetaController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group.
|
*/

// Home Page
Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

// Product Page
Route::get('/products', [App\Http\Controllers\ProductController::class, 'index'])->name('products.index');
Route::get('/product/{slug}', [App\Http\Controllers\ProductController::class, 'show'])->name('products.show');
Route::get('/products/{slug}', [App\Http\Controllers\ProductController::class, 'show'])->name('products.show.plural'); // Support both URL patterns

// Sitemap
Route::get('/sitemap.xml', [App\Http\Controllers\SitemapController::class, 'index']);

// Cart
Route::get('/cart', [App\Http\Controllers\CartController::class, 'index'])->name('cart.index');
Route::get('/wishlist', [App\Http\Controllers\WishlistController::class, 'index'])->name('wishlist.index');

// Admin Panel (Serve React App)
Route::get('/admin/{any?}', [MetaController::class, 'default'])->where('any', '.*');

// Fallback (Disabled)
// Route::fallback([MetaController::class, 'default']);
