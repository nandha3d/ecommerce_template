<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SiteSettingSeeder extends Seeder
{
    public function run(): void
    {
        $settings = [
            ['key' => 'site.name', 'value' => 'UltraPro Supplements', 'is_public' => true],
            ['key' => 'site.description', 'value' => 'Premium Performance Supplements', 'is_public' => true],
            ['key' => 'contact.email', 'value' => 'support@ultrapro.com', 'is_public' => true],
        ];

        foreach ($settings as $setting) {
            DB::table('site_settings')->updateOrInsert(
                ['key' => $setting['key']],
                $setting
            );
        }
    }
}
