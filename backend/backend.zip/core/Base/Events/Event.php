<?php

namespace Core\Base\Events;

interface Event
{
    // Marker interface for events
}
