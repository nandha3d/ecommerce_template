import{j as r}from"./index-BSOonGZR.js";const l=({children:s,className:t="",hover:e=!0,padding:o="md",onClick:a})=>{const d={none:"",sm:"p-3",md:"p-5",lg:"p-8"};return r.jsx("div",{onClick:a,className:`
        bg-white rounded-xl border border-neutral-200/50 overflow-hidden
        shadow-card transition-all duration-300
        ${e?"hover:shadow-soft":""}
        ${a?"cursor-pointer":""}
        ${d[o]}
        ${t}
      `,children:s})},i=({children:s,className:t=""})=>r.jsx("div",{className:`mb-4 ${t}`,children:s}),c=({children:s,className:t=""})=>r.jsx("h3",{className:`text-lg font-bold text-neutral-900 ${t}`,children:s}),m=({children:s,className:t=""})=>r.jsx("div",{className:t,children:s});export{l as C,i as a,c as b,m as c};
