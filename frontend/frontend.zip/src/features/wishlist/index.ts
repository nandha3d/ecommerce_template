export { default as WishlistPage } from './WishlistPage';
