export { default as CheckoutPage } from './CheckoutPage';
